"""DragonReserve 远程服务控制器
装好后，库库AI 即可通过 HTTP 调用远程 启动/停止/查看 你的 Uvicorn 后端。
安全：需要 X-Token 头鉴权；默认只监听 127.0.0.1（要远程控制时再按 README 放开）。
"""
import os
import pathlib
import subprocess

from fastapi import FastAPI, Header, HTTPException
import uvicorn

TOKEN = os.environ.get("DRAGONRESERVE_CTL_TOKEN", "change-me-please")
DEVCTL = os.environ.get(
    "DRAGONRESERVE_DEVCTL",
    str(pathlib.Path(__file__).resolve().with_name("devctl.sh")),
)
CTL_PORT = int(os.environ.get("DRAGONRESERVE_CTL_PORT", "9100"))
CTL_HOST = os.environ.get("DRAGONRESERVE_CTL_HOST", "127.0.0.1")

app = FastAPI(title="DragonReserve Service Controller", docs_url=None, redoc_url=None)


def _auth(x_token: str | None) -> None:
    if not x_token or x_token != TOKEN:
        raise HTTPException(status_code=401, detail="unauthorized")


def _run(*args: str) -> dict:
    p = subprocess.run(
        ["bash", DEVCTL, *args], capture_output=True, text=True, timeout=90
    )
    return {"ok": p.returncode == 0, "output": (p.stdout + p.stderr).strip()}


@app.get("/status")
def status(x_token: str | None = Header(default=None)):
    _auth(x_token)
    return _run("status")


@app.post("/start")
def start(x_token: str | None = Header(default=None)):
    _auth(x_token)
    return _run("start")


@app.post("/stop")
def stop(x_token: str | None = Header(default=None)):
    _auth(x_token)
    return _run("stop")


@app.post("/restart")
def restart(x_token: str | None = Header(default=None)):
    _auth(x_token)
    return _run("restart")


@app.get("/logs")
def logs(tail: int = 100, x_token: str | None = Header(default=None)):
    _auth(x_token)
    return _run("logs", str(tail))


if __name__ == "__main__":
    uvicorn.run(app, host=CTL_HOST, port=CTL_PORT)
