# DragonReserve 后端「通过库库AI启动服务」安装说明

一次安装（约 5 分钟），以后在对话里说「启动服务」即可由我远程拉起后端。

## 这套东西是什么
| 文件 | 作用 |
|---|---|
| `devctl.sh` | 本地一键脚本：`start/stop/restart/status/logs`，幂等，默认 8002 端口，自动识别 `.venv` 和 `main:app` |
| `server_ctl.py` | 远程控制器（FastAPI，默认 9100 端口），带 `X-Token` 鉴权，供我远程调用 |
| `dragonreserve-ctl.service` | systemd 用户级自启单元，让控制器开机常驻 |

## 安装步骤（在你的 Ubuntu 开发机上执行）
1. 解压到 DragonReserve 后端项目根目录（即 `main.py` / `.venv` 所在目录）：
   `unzip dragonreserve-ctl.zip -d <项目目录> && cd <项目目录> && chmod +x devctl.sh`
2. 先验证本地一键启动：`./devctl.sh start`，看到「已启动… http://127.0.0.1:8002」即 OK；
   若自动识别不对，用环境变量覆盖：`DRAGONRESERVE_APP=src.main:app DRAGONRESERVE_VENV=.venv ./devctl.sh start`
3. 装控制器依赖（若已有 fastapi/uvicorn 可跳过）：`python3 -m pip install fastapi uvicorn`
4. 设一个只有你和我知道的令牌，并把控制器挂成开机自启：
   ```bash
   mkdir -p ~/.config/systemd/user
   cp dragonreserve-ctl.service ~/.config/systemd/user/
   # 编辑该文件：改 WorkingDirectory 为项目目录、改 DRAGONRESERVE_CTL_TOKEN 为你的令牌
   systemctl --user daemon-reload
   systemctl --user enable --now dragonreserve-ctl
   loginctl enable-linger "$USER"   # 注销后仍常驻
   ```
5. 让我能访问到控制器（三选一，按你网络情况）：
   - 本地通道打开时：我直接访问 `http://127.0.0.1:9100`（默认即此模式，最安全）
   - 同一内网：把单元里 `DRAGONRESERVE_CTL_HOST` 改为 `0.0.0.0`，告诉我机器的内网 IP
   - 外网/我在云端：用你已有的内网穿透（如 cpolar/frp）把 9100 映射出去，把隧道地址和令牌告诉我

## 装好之后
- 你说「启动服务」→ 我调 `POST /start`；说「停掉/重启/看状态/看日志」→ 对应 `stop / restart / status / logs`。
- 令牌只存在你机器和你的记忆里，不要提交进 Git。
