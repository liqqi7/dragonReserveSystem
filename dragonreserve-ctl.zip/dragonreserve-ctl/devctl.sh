#!/usr/bin/env bash
# DragonReserve 后端服务一键管理（Uvicorn / 默认端口 8002）
# 用法: ./devctl.sh {start|stop|restart|status|logs [行数]}
set -euo pipefail

# ---------- 可配置区（自动识别不准时改这里，或用同名环境变量覆盖） ----------
PROJECT_DIR="${DRAGONRESERVE_DIR:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)}"
PORT="${DRAGONRESERVE_PORT:-8002}"
HOST="${DRAGONRESERVE_HOST:-0.0.0.0}"
APP_MODULE="${DRAGONRESERVE_APP:-}"        # 例如 main:app；留空自动识别
VENV_DIR="${DRAGONRESERVE_VENV:-}"         # 留空自动识别 .venv / venv / env
# ---------------------------------------------------------------------------

LOG_DIR="$PROJECT_DIR/logs"; PID_DIR="$PROJECT_DIR/run"
LOG_FILE="$LOG_DIR/backend.log"; PID_FILE="$PID_DIR/backend.pid"
mkdir -p "$LOG_DIR" "$PID_DIR"

log() { printf '[devctl] %s\n' "$*"; }

port_in_use() { ss -ltn 2>/dev/null | awk '{print $4}' | grep -qE "(^|:)${PORT}$"; }

pick_venv() {
  [[ -n "$VENV_DIR" ]] && return 0
  for d in "$PROJECT_DIR/.venv" "$PROJECT_DIR/venv" "$PROJECT_DIR/env"; do
    [[ -f "$d/bin/activate" ]] && VENV_DIR="$d" && return 0
  done
  VENV_DIR=""
}

pick_app_module() {
  [[ -n "$APP_MODULE" ]] && return 0
  local candidates=(main.py app.py server.py src/main.py src/app.py backend/main.py backend/app.py)
  for f in "${candidates[@]}"; do
    if [[ -f "$PROJECT_DIR/$f" ]] && grep -qE "FastAPI\(|APIRouter\(|uvicorn" "$PROJECT_DIR/$f" 2>/dev/null; then
      local mod="${f%.py}"; APP_MODULE="${mod//\//.}:app"; return 0
    fi
  done
  APP_MODULE="main:app"
}

ensure_uvicorn() {
  if [[ -n "$VENV_DIR" ]]; then # shellcheck disable=SC1091
    source "$VENV_DIR/bin/activate"
  fi
  if ! command -v uvicorn >/dev/null 2>&1; then
    log "未找到 uvicorn，尝试安装（python3 -m pip install uvicorn fastapi）..."
    python3 -m pip install --quiet uvicorn fastapi || { log "依赖安装失败，请先手动装好 uvicorn"; exit 1; }
  fi
}

start() {
  if port_in_use; then log "端口 $PORT 已在监听，服务已在运行（幂等跳过）。"; status; return 0; fi
  pick_venv; pick_app_module; ensure_uvicorn
  log "启动 DragonReserve 后端：模块=$APP_MODULE 端口=$PORT 目录=$PROJECT_DIR"
  cd "$PROJECT_DIR"
  nohup uvicorn "$APP_MODULE" --host "$HOST" --port "$PORT" >>"$LOG_FILE" 2>&1 &
  echo $! > "$PID_FILE"
  for _ in $(seq 1 30); do
    if port_in_use; then log "已启动 (PID $(cat "$PID_FILE"))，地址 http://127.0.0.1:$PORT"; return 0; fi
    if ! kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then
      log "进程已退出，最近 20 行日志："; tail -n 20 "$LOG_FILE" || true; exit 1
    fi
    sleep 0.5
  done
  log "等待 15 秒后端口仍未监听，请查看日志 $LOG_FILE"; exit 1
}

stop() {
  local pid=""
  if [[ -f "$PID_FILE" ]] && kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then pid="$(cat "$PID_FILE")"; fi
  if [[ -z "$pid" ]] && port_in_use; then
    pid="$(ss -ltnp 2>/dev/null | grep -E ":${PORT} " | grep -oP 'pid=\K[0-9]+' | head -1 || true)"
  fi
  if [[ -n "$pid" ]]; then
    kill "$pid" 2>/dev/null || true; sleep 1; kill -9 "$pid" 2>/dev/null || true
    rm -f "$PID_FILE"; log "已停止 (PID $pid)"
  else
    log "服务未在运行。"
  fi
}

status() {
  if port_in_use; then
    local pid="?"; [[ -f "$PID_FILE" ]] && pid="$(cat "$PID_FILE")"
    log "运行中：端口 $PORT 监听中，PID $pid"
  else
    log "未运行（端口 $PORT 空闲）。"
  fi
}

case "${1:-}" in
  start) start ;;
  stop) stop ;;
  restart) stop || true; start ;;
  status) status ;;
  logs) tail -n "${2:-100}" "$LOG_FILE" ;;
  *) echo "用法: $0 {start|stop|restart|status|logs [行数]}"; exit 2 ;;
esac
